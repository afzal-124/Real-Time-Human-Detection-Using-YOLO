# Real-Time Human Detection Using YOLO

A simple mini-project that detects people in a live webcam feed or video using a pretrained YOLO model. It draws bounding boxes, displays the number of people detected in each frame, and shows an approximate FPS value.

## Features
- Real-time webcam detection
- Person-only detection (COCO class ID 0)
- Bounding boxes and model confidence labels
- Live people count and approximate FPS
- Can process a saved video file too

## Requirements
- Python 3.9–3.12 recommended
- Webcam (for live mode)
- Internet connection for the first model-weight download
- Windows, macOS, or Linux

## Setup
Open Terminal in this project folder and run:

```bash
python -m venv .venv
```

Activate the environment:
- Windows: `.venv\\Scripts\\activate`
- macOS/Linux: `source .venv/bin/activate`

Install dependencies:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Run webcam detection:

```bash
python src/main.py
```

Run detection on a video:

```bash
python src/main.py --source sample.mp4
```

Change the confidence threshold:

```bash
python src/main.py --confidence 0.55
```

Press **Q** or **Esc** to close the window.

## How it works
1. OpenCV reads frames from the webcam or video.
2. The pretrained YOLO model predicts objects in each frame.
3. The program filters detections to the `person` class (class ID 0).
4. YOLO draws bounding boxes and confidence labels.
5. OpenCV displays the frame, person count, and approximate FPS.

## Troubleshooting
- If the webcam does not open, close other apps using it and check camera permissions.
- If the first run is slow, the model weights may be downloading or the machine may be initializing the model.
- On macOS, allow camera access to the terminal/IDE running Python.
- If installation fails, use Python 3.10 or 3.11 in a fresh virtual environment.
- A CPU can run the project, but speed depends on hardware and frame size.

## Project limitations
Detection accuracy and speed vary with lighting, occlusion, camera angle, and hardware. This demo is not designed for identity recognition or safety-critical decisions. It detects the visual `person` category; it does not identify who a person is.
