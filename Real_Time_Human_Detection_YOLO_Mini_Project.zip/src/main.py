"""
Real-Time Human Detection Using YOLO
Detects people (COCO class ID 0) from a webcam or video file.
Run: python src/main.py
Optional: python src/main.py --source path/to/video.mp4
"""
import argparse
import time
import cv2
from ultralytics import YOLO

def parse_args():
    parser = argparse.ArgumentParser(description="Real-Time Human Detection Using YOLO")
    parser.add_argument("--source", default="0", help="Webcam index (default 0) or video file path")
    parser.add_argument("--model", default="yolov8n.pt", help="Ultralytics YOLO model weights")
    parser.add_argument("--confidence", type=float, default=0.40, help="Confidence threshold (0-1)")
    return parser.parse_args()

def main():
    args = parse_args()
    source = int(args.source) if args.source.isdigit() else args.source
    model = YOLO(args.model)  # Downloads official pretrained weights on first run if needed.
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise SystemExit(f"Error: Could not open video source: {args.source}. Check webcam permissions/source.")

    previous_time = time.time()
    print("Press Q or ESC to quit.")
    while True:
        ok, frame = cap.read()
        if not ok:
            break

        results = model.predict(frame, conf=args.confidence, classes=[0], verbose=False)
        person_count = 0
        for result in results:
            person_count = len(result.boxes)
            frame = result.plot()

        now = time.time()
        fps = 1.0 / max(now - previous_time, 1e-6)
        previous_time = now
        cv2.putText(frame, f"People detected: {person_count}", (15, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, f"FPS: {fps:.1f}", (15, 68),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.imshow("Real-Time Human Detection Using YOLO", frame)
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
